import { ArrowLeft, Blocks, CheckCircle2, Heart, ShoppingBag, Tag, Undo2 } from "lucide-react";
import { type FormEvent, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useAuthenticatedUser } from "@/auth/auth-context";
import { Button } from "@/components/ui/button";
import { ErrorState, LoadingState } from "@/components/ui/page-state";
import { SafeMedia } from "@/components/ui/safe-media";
import { TextField } from "@/components/ui/text-field";
import { api } from "@/lib/api/services";
import { getUserFacingError } from "@/lib/api/errors";
import { useApiResource } from "@/lib/hooks/use-api-resource";
import { formatDateTime, formatMoney } from "@/lib/formatters";

type TransactionIntent = { action: "buy" | "unsell"; price: number } | { action: "sell"; price: number };

function getFavouriteId(value: Awaited<ReturnType<typeof api.getFavourites>>[number]) {
  if (typeof value === "string" || typeof value === "number") return String(value);
  const id = value.nft_id ?? value.pic?.id ?? value.id;
  return id === undefined ? null : String(id);
}

export function NftPage() {
  const { nftId = "" } = useParams();
  const { refreshUser } = useAuthenticatedUser();
  const nft = useApiResource(nftId ? `nft:${nftId}` : null, (signal) => api.getNft(nftId, signal));
  const favourites = useApiResource("favourites", (signal) => api.getFavourites(signal));
  const [pending, setPending] = useState(false);
  const [favouritePending, setFavouritePending] = useState(false);
  const [feedback, setFeedback] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [intent, setIntent] = useState<TransactionIntent | null>(null);
  const isFavourite = useMemo(() => favourites.status === "success" && favourites.data.some((value) => getFavouriteId(value) === nftId), [favourites, nftId]);

  async function transact(action: "buy" | "sell" | "unsell", price?: number) {
    if (nft.status !== "success") return;
    if ((action === "sell" || action === "unsell") && nft.data.own_id === undefined) {
      setFeedback({ type: "error", text: "Backend не вернул идентификатор владения для этой операции." });
      return;
    }
    setPending(true);
    setFeedback(null);
    try {
      if (action === "buy") await api.buyNft(nftId);
      if (action === "sell" && nft.data.own_id !== undefined && price !== undefined) await api.sellNft(String(nft.data.own_id), price);
      if (action === "unsell" && nft.data.own_id !== undefined) await api.unsellNft(String(nft.data.own_id));
      setFeedback({ type: "success", text: action === "buy" ? "Покупка завершена." : action === "sell" ? "NFT выставлен на продажу." : "NFT снят с продажи." });
      setIntent(null);
      nft.refresh();
      await refreshUser();
    } catch (error) {
      setFeedback({ type: "error", text: getUserFacingError(error) });
    } finally { setPending(false); }
  }

  function submitSale(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const price = Number(new FormData(event.currentTarget).get("price"));
    if (!Number.isFinite(price) || price <= 0) { setFeedback({ type: "error", text: "Введите корректную цену." }); return; }
    setIntent({ action: "sell", price });
  }

  async function toggleFavourite() {
    if (favouritePending) return;
    setFavouritePending(true); setFeedback(null);
    try {
      if (isFavourite) await api.deleteFavourite(nftId); else await api.addFavourite(nftId);
      favourites.refresh();
      setFeedback({ type: "success", text: isFavourite ? "Удалено из избранного." : "Добавлено в избранное." });
    } catch (error) {
      setFeedback({ type: "error", text: getUserFacingError(error) });
    } finally {
      setFavouritePending(false);
    }
  }

  if (nft.status === "loading") return <main className="container page"><LoadingState label="Загружаем NFT" /></main>;
  if (nft.status === "error") return <main className="container page"><ErrorState message={getUserFacingError(nft.error)} onRetry={nft.refresh} /></main>;
  const item = nft.data;

  return (
    <main className="container page">
      <Link to={`/client/collection/${item.collection_id}`} className="back-link"><ArrowLeft size={16} /> {item.collection_name}</Link>
      <div className="asset-layout">
        <section className="asset-preview"><SafeMedia src={item.image} alt={`${item.collection_name} #${item.number}`} eager /></section>
        <section className="asset-details">
          <span className="pill"><Blocks size={13} /> {item.blockchain || "Сеть не указана"}</span>
          <div className="asset-title"><div><Link to={`/client/collection/${item.collection_id}`} className="asset-details__collection">{item.collection_name}</Link><h1>#{item.number}</h1></div><Button variant="secondary" aria-label={isFavourite ? "Удалить из избранного" : "Добавить в избранное"} title={favourites.status === "error" ? getUserFacingError(favourites.error) : undefined} disabled={favouritePending || favourites.status !== "success"} onClick={() => void toggleFavourite()}><Heart fill={isFavourite ? "currentColor" : "none"} />{favourites.status === "error" ? "Избранное недоступно" : isFavourite ? "В избранном" : "В избранное"}</Button></div>
          <div className="price-panel"><span>Текущая цена</span><strong>{formatMoney(item.is_sale && item.sale_price ? item.sale_price : item.price, item.currency)}</strong></div>
          {feedback ? <div className={feedback.type === "success" ? "inline-alert inline-alert--success" : "inline-alert"} role="status">{feedback.type === "success" ? <CheckCircle2 size={17} /> : null}{feedback.text}</div> : null}
          <div className="asset-actions">
            {item.is_own ? <form className="sale-form" onSubmit={submitSale}><TextField name="price" type="number" min="0.01" step="0.01" label="Цена продажи" disabled={pending} required /><Button type="submit" disabled={pending}><Tag size={17} /> Выставить на продажу</Button></form> : item.is_sale ? <Button variant="secondary" disabled={pending} onClick={() => setIntent({ action: "unsell", price: item.sale_price })}><Undo2 size={17} /> Снять с продажи</Button> : <Button size="large" disabled={pending} onClick={() => setIntent({ action: "buy", price: item.price })}><ShoppingBag size={18} /> Купить за {formatMoney(item.price, item.currency)}</Button>}
          </div>
          {intent ? <section className="transaction-confirmation" aria-label="Подтверждение операции"><strong>{intent.action === "buy" ? "Подтвердите покупку" : intent.action === "sell" ? "Подтвердите размещение" : "Снять NFT с продажи?"}</strong><p>{item.collection_name} #{item.number} · {item.blockchain || "сеть не указана"}{intent.action !== "unsell" ? ` · ${formatMoney(intent.price, item.currency)}` : ""}</p><div><Button disabled={pending} onClick={() => void transact(intent.action, intent.price)}>{pending ? "Выполняем…" : "Подтвердить"}</Button><Button variant="ghost" disabled={pending} onClick={() => setIntent(null)}>Отмена</Button></div></section> : null}
          <dl className="asset-meta"><div><dt>Collection</dt><dd>{item.collection_name}</dd></div><div><dt>Token ID</dt><dd>{item.number}</dd></div><div><dt>Blockchain</dt><dd>{item.blockchain || "—"}</dd></div></dl>
        </section>
      </div>
      <section className="asset-history"><div className="section-heading"><div><h2>История цены</h2><p>Данные, предоставленные marketplace API</p></div></div>{item.prices.length ? <div className="history-list">{[...item.prices].reverse().map((point, index) => <div key={`${point.time}-${index}`}><span>{formatDateTime(point.time)}</span><strong>{formatMoney(point.value, item.currency)}</strong></div>)}</div> : <div className="state-panel">История цены пока недоступна.</div>}</section>
    </main>
  );
}
