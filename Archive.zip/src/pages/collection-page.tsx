import { ArrowLeft, Blocks, Search } from "lucide-react";
import { useMemo } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { NftCard } from "@/components/nft-card";
import { CardGridSkeleton, EmptyState, ErrorState } from "@/components/ui/page-state";
import { api } from "@/lib/api/services";
import { getUserFacingError } from "@/lib/api/errors";
import { useApiResource } from "@/lib/hooks/use-api-resource";
import { formatCompactNumber, formatMoney } from "@/lib/formatters";

export function CollectionPage() {
  const { collectionId = "" } = useParams();
  const [params, setParams] = useSearchParams();
  const query = params.get("q") ?? "";
  const collection = useApiResource(collectionId ? `collection:${collectionId}` : null, (signal) => api.getCollection(collectionId, signal));
  const visibleNfts = useMemo(() => collection.status === "success" ? collection.data.nfts.filter((nft) => String(nft.number).toLowerCase().includes(query.toLowerCase())) : [], [collection, query]);

  if (collection.status === "loading") return <main className="page container"><div className="collection-hero skeleton" /><CardGridSkeleton /></main>;
  if (collection.status === "error") return <main className="page container"><ErrorState message={getUserFacingError(collection.error)} onRetry={collection.refresh} /></main>;

  const details = collection.data;
  return (
    <main className="page collection-page">
      <div className="collection-hero"><div className="collection-hero__glow" /><div className="container collection-hero__inner"><Link to="/client/main" className="back-link"><ArrowLeft size={16} /> Все коллекции</Link><div className="collection-identity"><span className="collection-avatar"><Blocks /></span><div><span className="pill"><Blocks size={13} /> {details.nfts[0]?.blockchain || "Сеть не указана"}</span><h1>{details.name}</h1><p>Автор: {details.author || "не указан"}</p></div></div><dl className="collection-stats"><div><dt>Объектов</dt><dd>{formatCompactNumber(details.nfts.length)}</dd></div><div><dt>В коллекции</dt><dd>{formatCompactNumber(details.in_own)}</dd></div><div><dt>Минимальная цена</dt><dd>{formatMoney(details.min_price, details.nfts[0]?.currency ?? "USD")}</dd></div><div><dt>Максимальная цена</dt><dd>{formatMoney(details.max_price, details.nfts[0]?.currency ?? "USD")}</dd></div></dl></div></div>
      <div className="container collection-content">
        <div className="collection-toolbar"><div><strong>Items</strong><span>{visibleNfts.length} из {details.nfts.length}</span></div><label className="search-box collection-search"><Search size={18} /><input className="field__input" value={query} onChange={(event) => { const next = new URLSearchParams(params); const value = event.target.value; if (value) next.set("q", value); else next.delete("q"); setParams(next, { replace: true }); }} placeholder="Поиск по token ID" /></label></div>
        {visibleNfts.length ? <div className="nft-grid">{visibleNfts.map((nft) => <NftCard key={String(nft.id)} nft={nft} collectionName={details.name} />)}</div> : <EmptyState title="NFT не найдены" description={query ? "Измените поисковый запрос." : "В этой коллекции пока нет объектов."} />}
      </div>
    </main>
  );
}
