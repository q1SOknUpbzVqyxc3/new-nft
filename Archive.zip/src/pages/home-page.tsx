import { Search, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { CollectionCard } from "@/components/collection-card";
import { SafeMedia } from "@/components/ui/safe-media";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/page-state";
import { api } from "@/lib/api/services";
import { getUserFacingError } from "@/lib/api/errors";
import { useApiResource } from "@/lib/hooks/use-api-resource";
import { useDebouncedValue } from "@/lib/hooks/use-debounced-value";
import { formatMoney } from "@/lib/formatters";

export function HomePage() {
  const collections = useApiResource("collections", (signal) => api.getCollections(signal));
  const [params, setParams] = useSearchParams();
  const [query, setQuery] = useState(params.get("q") ?? "");
  const debouncedQuery = useDebouncedValue(query.trim(), 350);
  const search = useApiResource(debouncedQuery ? `search:${debouncedQuery}` : null, (signal) => api.search(debouncedQuery, signal));

  useEffect(() => {
    setParams((current) => {
      const next = new URLSearchParams(current);
      if (debouncedQuery) next.set("q", debouncedQuery); else next.delete("q");
      return next;
    }, { replace: true });

  }, [debouncedQuery, setParams]);

  return (
    <main className="page container">
      <header className="market-hero">
        <div><span className="eyebrow">Curated marketplace</span><h1>Откройте свою следующую коллекцию</h1><p>Исследуйте реальные активы Monvravex и управляйте покупками в одном месте.</p></div>
        <div className="search-box market-search">
          <Search size={19} />
          <input className="field__input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Поиск по NFT и коллекциям" aria-label="Поиск" />
          {query ? <button type="button" className="search-clear" aria-label="Очистить поиск" onClick={() => setQuery("")}><X size={16} /></button> : null}
          {debouncedQuery ? <div className="search-results" role="region" aria-label="Результаты поиска">
            {search.status === "loading" ? <LoadingState label="Ищем" /> : search.status === "error" ? <div className="search-message" role="alert">{getUserFacingError(search.error)}</div> : search.data.length ? search.data.map((item) => <Link to={`/client/collectible/${item.id}`} className="search-result" key={String(item.id)}><SafeMedia src={item.image} alt={`${item.collection_name} #${item.number}`} /><div className="search-result__body"><strong>{item.collection_name} #{item.number}</strong><span>{item.blockchain}</span></div><span className="search-result__price">{formatMoney(item.price, item.currency)}</span></Link>) : <div className="search-message">Ничего не найдено</div>}
          </div> : null}
        </div>
      </header>
      <section>
        <div className="section-heading"><div><span className="eyebrow">Marketplace</span><h2>Коллекции</h2><p>Доступные коллекции и актуальная минимальная цена</p></div></div>
        {collections.status === "loading" ? <LoadingState label="Загружаем коллекции" /> : collections.status === "error" ? <ErrorState message={getUserFacingError(collections.error)} onRetry={collections.refresh} /> : collections.data.length ? <div className="collection-grid">{collections.data.map((collection, index) => <CollectionCard key={String(collection.id)} collection={collection} featured={index === 0} />)}</div> : <EmptyState title="Коллекций пока нет" description="Новые коллекции появятся здесь после публикации." />}
      </section>
    </main>
  );
}
