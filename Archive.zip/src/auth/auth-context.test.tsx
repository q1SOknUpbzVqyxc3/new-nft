import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { AuthProvider, useAuth } from "./auth-context";

function jsonResponse(payload: unknown, status = 200) {
  return new Response(JSON.stringify(payload), { status, headers: { "Content-Type": "application/json" } });
}

function AuthProbe() {
  const auth = useAuth();
  return <div><span>{auth.status}</span>{auth.status === "authenticated" ? <strong>{auth.user.email}</strong> : null}<button type="button" onClick={() => void auth.login({ email: "user@example.com", password: "Strong1!", remember: true })}>login</button></div>;
}

describe("AuthProvider", () => {
  afterEach(() => {
    cleanup();
    vi.unstubAllGlobals();
  });

  it("resolves an absent cookie session as unauthenticated", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(jsonResponse({ detail: "Not authenticated" }, 403)));
    render(<AuthProvider><AuthProbe /></AuthProvider>);
    await waitFor(() => expect(screen.getByText("unauthenticated")).toBeInTheDocument());
  });

  it("restores the user after successful login", async () => {
    const user = { id: 1, email: "user@example.com", username: null, avatar: "", balance: 0, currency: "USD", active: true, verificated: false, can_withdraw: true, turnover: 0, created: "", minimal_deposit: 0 };
    const fetchMock = vi.fn()
      .mockResolvedValueOnce(jsonResponse({ detail: "Not authenticated" }, 403))
      .mockResolvedValueOnce(jsonResponse(true))
      .mockResolvedValueOnce(jsonResponse(user));
    vi.stubGlobal("fetch", fetchMock);
    render(<AuthProvider><AuthProbe /></AuthProvider>);
    await waitFor(() => expect(screen.getByText("unauthenticated")).toBeInTheDocument());
    fireEvent.click(screen.getByRole("button", { name: "login" }));
    await waitFor(() => expect(screen.getByText("user@example.com")).toBeInTheDocument());
    expect(fetchMock).toHaveBeenCalledTimes(3);
  });
});
