import { CircleDollarSign, LogOut, Menu, Moon, UserRound, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "@/auth/auth-context";
import { navigationItems } from "@/lib/navigation";
import { formatMoney } from "@/lib/formatters";
import { ActivationGate } from "./activation-gate";
import { Brand } from "./brand";
import { NotificationsMenu } from "./notifications-menu";
import { Button } from "./ui/button";

export function ClientLayout() {
  const auth = useAuth();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [theme, setTheme] = useState(() => window.localStorage.getItem("theme") ?? "dark");

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    window.localStorage.setItem("theme", theme);
  }, [theme]);

  async function logout() {
    await auth.logout();
    await navigate("/auth/login", { replace: true });
  }

  if (auth.status !== "authenticated") return null;
  if (!auth.user.active) return <ActivationGate />;
  const currentUser = auth.user;

  return (
    <>
      <header className="app-header">
        <div className="app-header__inner container">
          <Brand />
          <nav className={menuOpen ? "main-nav main-nav--open" : "main-nav"} aria-label="Основная навигация">
            {navigationItems.filter((item) => item.primary).map((item) => <NavLink to={item.to} key={item.to} onClick={() => setMenuOpen(false)}>{item.label}</NavLink>)}
          </nav>
          <div className="header-actions">
            <Link to="/client/topup" className="balance-chip"><CircleDollarSign size={16} /><span>{formatMoney(currentUser.balance, currentUser.currency)}</span></Link>
            <Link to="/client/profile" className="icon-button" aria-label="Профиль"><UserRound size={19} /></Link>
            <NotificationsMenu />
            <Button variant="ghost" className="desktop-only" aria-label="Сменить тему" onClick={() => setTheme((value) => value === "dark" ? "light" : "dark")}><Moon size={18} /></Button>
            <Button variant="ghost" className="desktop-only" aria-label="Выйти" onClick={() => void logout()}><LogOut size={18} /></Button>
            <button className="menu-button" type="button" aria-expanded={menuOpen} aria-label="Меню" onClick={() => setMenuOpen((value) => !value)}>{menuOpen ? <X /> : <Menu />}</button>
          </div>
        </div>
        {menuOpen ? <div className="mobile-menu container">{navigationItems.filter((item) => !item.primary).map((item) => <Link to={item.to} key={item.to} onClick={() => setMenuOpen(false)}><item.icon /> {item.label}</Link>)}<button type="button" onClick={() => setTheme((value) => value === "dark" ? "light" : "dark")}><Moon /> Сменить тему</button><button type="button" onClick={() => void logout()}><LogOut /> Выйти</button></div> : null}
      </header>
      <Outlet />
    </>
  );
}
