import { Link } from "react-router-dom";
import { ArrowUpRight, Blocks } from "lucide-react";
import type { CollectionSummary } from "@/lib/api/schemas";
import { formatMoney } from "@/lib/formatters";
import { SafeMedia } from "./ui/safe-media";

export function CollectionCard({ collection, featured = false }: { collection: CollectionSummary; featured?: boolean }) {
  return (
    <article className={featured ? "collection-card collection-card--featured" : "collection-card"}>
      <Link to={`/client/collection/${collection.id}`} className="collection-card__link">
        <SafeMedia src={collection.image} alt={collection.name} className="collection-card__media" eager={featured} />
        <span className="collection-card__shade" />
        <div className="collection-card__content">
          <span className="collection-card__chain">
            <Blocks size={14} aria-hidden="true" />
            {collection.blockchain || "Сеть не указана"}
          </span>
          <div>
            <strong>{collection.name}</strong>
            <span>Floor {formatMoney(collection.follow, "USD")}</span>
          </div>
          <ArrowUpRight className="collection-card__arrow" aria-hidden="true" />
        </div>
      </Link>
    </article>
  );
}
